# GitHub Pages 入门网页

这是一个可直接部署到 GitHub Pages 的静态网页模板。

## 文件
- `index.html`：网站首页，包含 HTML、CSS 和少量 JavaScript。
- 不需要安装依赖，也不需要构建命令。

## 自定义
用文本编辑器打开 `index.html`，修改：
- 页面标题 `我的主页`
- 首页主标题和介绍文字
- 项目卡片标题与简介
- 关于我部分的内容

## 部署
1. 在 GitHub 新建一个仓库，例如 `my-first-website`。
2. 将 `index.html` 上传到仓库根目录。
3. 打开仓库 `Settings` → `Pages`。
4. 在 `Build and deployment` 下，选择 `Deploy from a branch`。
5. Branch 选择 `main`，目录选择 `/(root)`，点击 `Save`。
6. 等待部署完成，页面会显示网站地址。
